## Dependencies

- React Native **v0.73.0**
- Redux Toolkit (RTK) v2.0
- TypeScript
- React Navigation v6
- React Native Vector Icons
- Formik & Yup
- Axios
- React Native Keychain
- Redux persist
- React Native MMKV
- Storybook

### Used the boilerplate code at below link for the RN-Redux-Typescript setup

```
https://github.com/saheeranas/react-native-redux-boilerplate.git

```

### Open project folder and install dependencies

```
yarn
or
npm i
```

### Rename environment variable files

Example: .env.template file to .env

### Run the project

For iOS run below commands after yarn/npm install

```
cd ios
pod install
```

```
yarn ios
or
npm run ios
```

or

```
yarn android
or
npm run android
```

## Please check the screenshots under app/assets/demo for the functionality implemented.

## Please comment the routes other than NativeCounter to check the RN Native iOS Module integration working

## Implemented Typography & Theming

## Wrote Sample test cases and tested the setup

## Additionally, for the production setup, will have to integrate Fastlane/App center or some automation process for publishing the app all the way to App/Play Store. and need to change the package name/bundle id to real time strings
