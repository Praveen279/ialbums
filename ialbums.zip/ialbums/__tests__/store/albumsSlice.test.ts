import reducer from '../../app/store/albumsSlice';

test('should return the initial state', () => {
  expect(reducer(undefined, {type: undefined})).toEqual({
    albums: [],
  });
});
