import {routes, get} from './index';

export const getAlbums = () => {
  return get(`${routes.albums}`);
};
