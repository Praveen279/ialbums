import {routes, get} from './index';

export const getPhotos = (albumId: number) => {
  return get(`${routes.photos}?albumId=${albumId}`);
};

export const getAllPhotos = () => {
  return get(`${routes.photos}`);
};
