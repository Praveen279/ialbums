import {routes, get} from './index';

export const getUsers = () => {
  return get(`${routes.users}`);
};
