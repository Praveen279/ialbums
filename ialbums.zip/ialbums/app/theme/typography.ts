import {Platform, StyleSheet} from 'react-native';

import {Typography, Fonts, FontWeights} from '../types/typography';

const ios: FontWeights = {
  '400': 'System',
  '500': 'System',
  '700': 'System',
};

const android: FontWeights = {
  '400': 'Roboto_400Regular',
  '500': 'Roboto_500Medium',
  '700': 'Roboto_700Bold',
};

const web: FontWeights = {
  '400': '-apple-system, BlinkMacSystemFont, Roboto, Arial, sans-serif',
  '500': '-apple-system, BlinkMacSystemFont, Roboto, Arial, sans-serif',
  '700': '-apple-system, BlinkMacSystemFont, Roboto, Arial, sans-serif',
};

const DEFAULT_LETTER_SPACING = 0;

export const fonts: Fonts = {
  weights: Platform.select({
    ios,
    android,
    web,
  }),
};

export const fontFamily = Platform.select({
  android,
  ios,
  web,
});

export const typography: Typography = StyleSheet.create({
  caption: {
    fontSize: 12,
    letterSpacing: DEFAULT_LETTER_SPACING,
    lineHeight: 14,
    fontFamily: fonts.weights[400],
  },
  small: {
    fontSize: 14,
    letterSpacing: DEFAULT_LETTER_SPACING,
    lineHeight: Platform.select({
      ios: 17,
      android: 16,
    }),
  },
  bodySmall: {
    letterSpacing: DEFAULT_LETTER_SPACING,
    fontSize: 16,
    lineHeight: 19,
  },
  bodyLarge: {
    fontSize: 18,
    letterSpacing: DEFAULT_LETTER_SPACING,
    lineHeight: 21,
  },
  headerSubtitle: {
    fontSize: 20,
    letterSpacing: DEFAULT_LETTER_SPACING,
    lineHeight: Platform.select({
      ios: 24,
      android: 23,
    }),
  },
  headerSmall: {
    fontSize: 24,
    letterSpacing: DEFAULT_LETTER_SPACING,
    lineHeight: Platform.select({
      ios: 29,
      android: 28,
    }),
  },
  headerLarge: {
    fontSize: 32,
    letterSpacing: DEFAULT_LETTER_SPACING,
    lineHeight: Platform.select({
      ios: 38,
      android: 35,
    }),
  },
});
