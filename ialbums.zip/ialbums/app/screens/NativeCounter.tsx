import React, {useEffect} from 'react';
import {
  Button,
  NativeEventEmitter,
  NativeModules,
  StyleSheet,
  View,
} from 'react-native';
import {Typography} from '../components/Typography';

const CounterEvents = new NativeEventEmitter(NativeModules.NativeCounter);

export const NativeCounterComponent = () => {
  useEffect(() => {
    CounterEvents.addListener('onIncrement', result =>
      console.log('onIncrement received', result),
    );
    CounterEvents.addListener('onDecrement', result =>
      console.log('onDecrement received', result),
    );

    return () => {
      CounterEvents.removeAllListeners('onIncrement');
      CounterEvents.removeAllListeners('onDecrement');
    };
  }, []);

  const decrement = async () => {
    try {
      var result = await NativeModules.NativeCounter.decrement();
      console.log(result);
    } catch (e) {
      console.log(e.message, e.code);
    }
  };
  const increment = async () => {
    NativeModules.NativeCounter.increment(res => console.log(res));
  };

  return (
    <View style={styles.container}>
      <Typography.BodySmall>Counter</Typography.BodySmall>
      <Button title="Increase Count" onPress={increment} />

      <Button title="Decrease Count" onPress={decrement} />
    </View>
  );
};
export default NativeCounterComponent;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
