import React, {useCallback, useEffect} from 'react';
import {FlatList, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {RootState} from '../store/store';
import {Photo} from '../types/photo';
import {PhotoView} from '../components/PhotoView';
import {getPhotos, getAllPhotos} from '../services';
import {setIsAllPhotosView, setPhotos} from '../store/photosSlice';
import Icon from 'react-native-vector-icons/AntDesign';

export const PhotoList = ({route, navigation}) => {
  const {albumId, albumName} = route.params;
  const isAllPhotosView: boolean = useSelector(
    (state: RootState) => state.photos.isAllPhotos,
  );

  const dispatch = useDispatch();

  const handleTypeSelection = () => {
    dispatch(setIsAllPhotosView());
  };

  navigation.setOptions({
    headerTitle: !isAllPhotosView ? albumName : 'All Photos',
    // eslint-disable-next-line react/no-unstable-nested-components
    headerRight: () => (
      <Icon
        onPress={handleTypeSelection}
        size={16}
        name={!isAllPhotosView ? 'staro' : 'star'}
        color={!isAllPhotosView ? '#000' : '#1260CC'}
      />
    ),
  });

  const photos: Photo[] = useSelector(
    (state: RootState) => state.photos.photos,
  );

  useEffect(() => {
    getPhotosList(!isAllPhotosView ? albumId : '');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAllPhotosView]);

  const getPhotosList = useCallback(
    async (aId?: number) => {
      const photosData = aId ? await getPhotos(aId) : await getAllPhotos();
      dispatch(setPhotos(photosData?.data || []));
    },
    [dispatch],
  );

  const renderItem = ({item}: {item: Photo}) => (
    <PhotoView key={`key-${item.id}`} photo={item} />
  );

  const keyExtractor = (photo: Photo): string => `photo-${photo.id}`;

  return (
    <View>
      <FlatList
        data={photos}
        numColumns={3}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
      />
    </View>
  );
};
