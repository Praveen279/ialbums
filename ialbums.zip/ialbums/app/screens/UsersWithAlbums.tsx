import React, {useEffect, useCallback} from 'react';
import {ScrollView, StyleSheet} from 'react-native';

import {useSelector, useDispatch} from 'react-redux';
import {RootState} from '../store/store';

// import {useTheme} from '../theme/useTheme';
import Layout from '../components/Layout';
import {User} from '../types/user';
import {getAlbums, getUsers} from '../services';
import {Album} from '../types/album';
import {setUsers} from '../store/usersSlice';
import {setAlbums} from '../store/albumsSlice';
import {UserAlbum} from '../components/UserAlbum';

const UsersWithAlbums = () => {
  // const {theme} = useTheme();
  const usersList: User[] = useSelector(
    (state: RootState) => state.users.users,
  );

  const albumsList: Album[] = useSelector(
    (state: RootState) => state.albums.albums,
  );
  const dispatch = useDispatch();

  useEffect(() => {
    getUsersList();
    getAlbumsList();
  });

  const getUsersList = useCallback(async () => {
    if (usersList && !usersList.length) {
      const users = await getUsers();
      dispatch(setUsers(users?.data || []));
    }
  }, [dispatch, usersList]);

  const getAlbumsList = useCallback(async () => {
    if (albumsList && !albumsList.length) {
      const albums = await getAlbums();
      dispatch(setAlbums(albums?.data || []));
    }
  }, [albumsList, dispatch]);

  const renderItem = ({item}: {item: User}) => (
    <UserAlbum
      key={`user-album-${item.id}`}
      username={item.name}
      albums={albumsList.filter(a => a.userId === item.id && !a.isDeleted)}
    />
  );

  return (
    <Layout>
      <ScrollView style={styles.container}>
        {usersList.map((item: User) => renderItem({item}))}
      </ScrollView>
    </Layout>
  );
};

export default UsersWithAlbums;

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
  },
});
