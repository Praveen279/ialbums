import React from 'react';
import {View, Text} from 'react-native';

const Dummy = () => {
  return (
    <View>
      <Text>Hello World</Text>
    </View>
  );
};

export default Dummy;
