import React from 'react';
import {ScrollView, StyleSheet, View} from 'react-native';
import {Album} from '../types/album';
import {AlbumListItem} from './AlbumListItem';
import {Typography} from './Typography';
import {themeType} from '../theme/theme';
import {useTheme} from '../theme/useTheme';

type UserAlbumProps = {
  username: string;
  albums: Album[];
};

export const UserAlbum = ({username, albums}: UserAlbumProps) => {
  const {theme} = useTheme();
  const styles = makeStyles(theme);
  const renderItem = ({item}: {item: Album}) => (
    <AlbumListItem key={`album-${item.id}`} album={item} />
  );

  return (
    <>
      <View style={styles.userName}>
        <Typography.BodyLarge medium>{username}</Typography.BodyLarge>
      </View>
      <ScrollView>{albums.map(album => renderItem({item: album}))}</ScrollView>
    </>
  );
};

const makeStyles = (theme: themeType) =>
  StyleSheet.create({
    userName: {
      padding: 10,
      backgroundColor: theme.user.bgColor,
    },
  });
