import React from 'react';

import {BaseTypography} from './BaseTypography';
import type {OmittedTypographyProps} from './types';

export const Caption = (props: OmittedTypographyProps): JSX.Element => {
  return (
    <BaseTypography type={'caption'} {...props}>
      {props.children}
    </BaseTypography>
  );
};
