import React from 'react';

import {BaseTypography} from './BaseTypography';
import type {OmittedTypographyProps} from './types';

export const HeaderSmall = (props: OmittedTypographyProps): JSX.Element => {
  return (
    <BaseTypography type={'headerSmall'} {...props}>
      {props.children}
    </BaseTypography>
  );
};

export const HeaderSubtitle = (props: OmittedTypographyProps): JSX.Element => {
  return (
    <BaseTypography type={'headerSubtitle'} {...props}>
      {props.children}
    </BaseTypography>
  );
};

export const HeaderLarge = (props: OmittedTypographyProps): JSX.Element => {
  return (
    <BaseTypography type={'headerLarge'} {...props}>
      {props.children}
    </BaseTypography>
  );
};
