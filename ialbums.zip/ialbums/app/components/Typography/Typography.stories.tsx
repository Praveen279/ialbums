import React from 'react';
import {Story} from '@storybook/react';

import {Typography as TypographyBase, TypographyProps} from './Typography';

const Template: Story<TypographyProps> = args => <TypographyBase {...args} />;

const argTypes = {
  children: {
    name: 'children',
    type: {
      name: 'string',
      required: true,
    },
  },
  type: {
    name: 'type',
    options: [0, 1, 2, 3, 4, 5, 6],
    mapping: [
      'caption',
      'small',
      'bodySmall',
      'bodyLarge',
      'headerSubtitle',
      'headerSmall',
      'headerLarge',
    ],
    control: {
      type: 'select',
      labels: [
        'caption',
        'small',
        'bodySmall',
        'bodyLarge',
        'headerSubtitle',
        'headerSmall',
        'headerLarge',
      ],
    },
  },
  weight: {
    name: 'weight',
    options: [0, 1, 2],
    mapping: ['400', '500', '700'],
    control: {
      type: 'select',
      labels: ['400', '500', '700'],
    },
  },
};

export const Typography = Template.bind({});

Typography.argTypes = argTypes;

Typography.args = {
  children: 'Typography',
};

export const Caption = Template.bind({});

Caption.argTypes = argTypes;

Caption.args = {
  type: 'caption',
  weight: '400',
  children: 'Caption (caption)',
};

export const Small = Template.bind({});

Small.argTypes = argTypes;

Small.args = {
  type: 'small',
  weight: '400',
  children: 'Small (small)',
};

export const BodySmall = Template.bind({});

BodySmall.argTypes = argTypes;

BodySmall.args = {
  type: 'bodySmall',
  weight: '400',
  children: 'BodySmall (bodySmall)',
};

export const BodyLarge = Template.bind({});

BodyLarge.argTypes = argTypes;

BodyLarge.args = {
  type: 'bodyLarge',
  weight: '400',
  children: 'BodyLarge (bodyLarge)',
};

export const HeaderSubtitle = Template.bind({});

HeaderSubtitle.argTypes = argTypes;

HeaderSubtitle.args = {
  type: 'headerSubtitle',
  weight: '400',
  children: 'HeaderSubtitle (headerSubtitle)',
};

export const HeaderSmall = Template.bind({});

HeaderSmall.argTypes = argTypes;

HeaderSmall.args = {
  type: 'headerSmall',
  weight: '400',
  children: 'HeaderSmall (headerSmall)',
};

export const HeaderLarge = Template.bind({});

HeaderLarge.argTypes = argTypes;

HeaderLarge.args = {
  type: 'headerLarge',
  weight: '400',
  children: 'HeaderLarge (headerLarge)',
};

export default {
  component: TypographyBase,
  title: '@311/components/Typography',
};
