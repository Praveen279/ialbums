import React from 'react';

import {BodySmall, BodyLarge} from './Body';
import {Caption} from './Caption';
import {HeaderSmall, HeaderSubtitle, HeaderLarge} from './Header';
import {Small} from './Small';

/**
 * @description
 *
 * - {TYPE} - {fontSize}
 * - caption - 12
 * - small - 14
 * - bodySmall - 16
 * - bodyLarge - 18
 * - headerSubtitle - 20
 * - headerSmall - 24
 * - headerLarge - 32
 *
 * @param {TypographyProps} props
 * @returns {JSX.Element}
 */
export const Typography = {
  BodySmall,
  BodyLarge,
  Caption,
  HeaderSmall,
  HeaderSubtitle,
  HeaderLarge,
  Small,
};

export const TypographyDemo = (): JSX.Element => {
  return (
    <>
      <Typography.Caption>Caption</Typography.Caption>

      <Typography.Small>Small</Typography.Small>

      <Typography.BodySmall>Body Small</Typography.BodySmall>

      <Typography.BodyLarge>Body Large</Typography.BodyLarge>

      <Typography.HeaderSubtitle>Header Subtitle</Typography.HeaderSubtitle>

      <Typography.HeaderSmall>Header Small</Typography.HeaderSmall>

      <Typography.HeaderLarge>Header Large</Typography.HeaderLarge>
    </>
  );
};
