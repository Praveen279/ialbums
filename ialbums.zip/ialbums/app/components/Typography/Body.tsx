import React from 'react';

import {BaseTypography} from './BaseTypography';
import type {OmittedTypographyProps} from './types';

export const BodySmall = (props: OmittedTypographyProps): JSX.Element => {
  return (
    <BaseTypography type={'bodySmall'} {...props}>
      {props.children}
    </BaseTypography>
  );
};

export const BodyLarge = (props: OmittedTypographyProps): JSX.Element => {
  return (
    <BaseTypography type={'bodyLarge'} {...props}>
      {props.children}
    </BaseTypography>
  );
};
