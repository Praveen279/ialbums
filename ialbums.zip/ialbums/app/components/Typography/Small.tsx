import React from 'react';

import {BaseTypography} from './BaseTypography';
import type {OmittedTypographyProps} from './types';

export const Small = (props: OmittedTypographyProps): JSX.Element => {
  return (
    <BaseTypography type={'small'} {...props}>
      {props.children}
    </BaseTypography>
  );
};
