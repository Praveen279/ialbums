import type {TypographyProps} from './BaseTypography';

export type OmittedTypographyProps = Omit<TypographyProps, 'type'>;
