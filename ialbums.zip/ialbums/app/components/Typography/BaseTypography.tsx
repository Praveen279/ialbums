import React from 'react';
import {
  Text,
  View,
  TextStyle,
  TextProps,
  StyleSheet,
  StyleProp,
} from 'react-native';
import {fontFamily, typography} from '../../theme/typography';
import {useTheme} from '../../theme/useTheme';
import {themeType} from 'app/theme/theme';

type TypographyType =
  | 'caption'
  | 'small'
  | 'bodySmall'
  | 'bodyLarge'
  | 'headerSubtitle'
  | 'headerSmall'
  | 'headerLarge';
type TypographyWeight = '400' | '500' | '700';

export interface BaseTypographyProps extends TextProps {
  style?: StyleProp<TextStyle>;
  children?: unknown;
  type: TypographyType;
  weight?: TypographyWeight;
}

export type TypographyProps = BaseTypographyProps & {
  bold?: boolean;
  medium?: boolean;
  accessible?: boolean;
  accessibilityLabel?: string;
};

/**
 * @description
 *
 * - {TYPE} - {fontSize}
 * - caption - 12
 * - small - 14
 * - bodySmall - 16
 * - bodyLarge - 18
 * - headerSubtitle - 20
 * - headerSmall - 24
 * - headerLarge - 32
 *
 * @param {TypographyProps} props
 * @returns {JSX.Element}
 */
export const BaseTypography = (props: TypographyProps): JSX.Element => {
  const {
    style,
    children,
    type,
    weight,
    bold,
    medium,
    accessible = false,
    accessibilityLabel = '',
    ...rest
  } = props;
  const {theme} = useTheme();

  /**
   * @description this function will return the font weight prop if it exists, but will only allow either bold or medium
   *  The order of operations on this:
   *  - bold
   *  - medium
   *  - weight
   *  So, if bold is set to true, that takes presidence over *everything* else
   * @param {TypographyFontWeightProps} weight
   * @param {boolean} bold
   * @param {boolean} medium
   * @returns {TypographyFontWeightProps}
   */
  const getWeight = (
    fontWeight: TypographyWeight,
    boldWeight?: boolean,
    isMedium?: boolean,
  ): TypographyWeight => {
    return boldWeight
      ? '700'
      : isMedium
      ? '500'
      : // since weight is defaulting to '400', we don't have to worry too much about this.
        fontWeight;
  };

  const styles = makeStyles(getWeight(weight, bold, medium), theme);

  const textStyles = [
    typography[type],
    styles.text,
    type in styles ? styles[type] : undefined,
    style,
  ];

  const textComponent = (
    <Text style={textStyles} {...rest}>
      {children}
    </Text>
  );

  return accessible ? (
    <View accessible={accessible} accessibilityLabel={accessibilityLabel}>
      {textComponent}
    </View>
  ) : (
    textComponent
  );
};

BaseTypography.defaultProps = {
  type: 'bodySmall',
  weight: '400',
};

const makeStyles = (weight: TypographyWeight, theme: themeType) =>
  StyleSheet.create({
    text: {
      fontFamily: fontFamily[weight],
      fontWeight: weight,
      color: theme.primaryText,
    },
    caption: {
      color: theme.primaryText,
    },
    small: {
      color: theme.primaryText,
    },
    bodySmall: {
      color: theme.primaryText,
    },
    bodyLarge: {
      color: theme.primaryText,
    },
    headerSubtitle: {
      color: theme.primaryText,
    },
    headerSmall: {
      color: theme.primaryText,
    },
    headerLarge: {
      color: theme.primaryText,
    },
  });
