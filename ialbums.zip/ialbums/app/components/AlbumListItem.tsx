import React from 'react';
import {View, StyleSheet} from 'react-native';
import {Album} from '../types/album';
import Icon from 'react-native-vector-icons/AntDesign';
import {markAlbumAsDeleted} from '../store/albumsSlice';
import {useDispatch} from 'react-redux';
import {useNavigation} from '@react-navigation/native';
import {Typography} from './Typography';

export const AlbumListItem = ({album}: {album: Album}) => {
  const dispatch = useDispatch();
  const {navigate} = useNavigation();

  const handleDelete = () => {
    dispatch(markAlbumAsDeleted({id: album.id}));
  };

  const handleAlbumSelection = () => {
    navigate('Photos', {albumId: album.id, albumName: album.title});
  };

  return (
    <View style={styles.root}>
      <Typography.BodySmall
        style={styles.albumName}
        onPress={handleAlbumSelection}>
        {album.title}
      </Typography.BodySmall>
      <Icon
        style={styles.icon}
        onPress={handleDelete}
        size={20}
        name="minuscircleo"
        color="#ff3823"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flexDirection: 'row',
    textAlign: 'right',
    borderWidth: 0.5,
    borderColor: '#efefef',
  },
  albumName: {
    textAlign: 'right',
    padding: 10,
    flexWrap: 'wrap',
    width: '90%',
  },
  icon: {
    alignSelf: 'center',
  },
});
