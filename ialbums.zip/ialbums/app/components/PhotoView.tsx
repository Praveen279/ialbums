import React from 'react';
import {Image, StyleSheet, Dimensions} from 'react-native';
import {Photo} from 'app/types/photo';

export const PhotoView = ({photo}: {photo: Photo}) => {
  const {width} = Dimensions.get('screen');

  const styles = makeStyles(width);
  return (
    <Image style={styles.image} src={photo.url} alt={photo.thumbnailUrl} />
  );
};

const makeStyles = (width: number) => {
  return StyleSheet.create({
    image: {
      width: Math.floor(width / 3),
      height: Math.floor(width / 3),
    },
  });
};
