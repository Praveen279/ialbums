import {createSlice} from '@reduxjs/toolkit';
import {Photo} from 'app/types/photo';

export type PhotoProps = {
  photos: Photo[];
  isAllPhotos: boolean;
};

const initialState: PhotoProps = {
  photos: [],
  isAllPhotos: false,
};

const photosSlice = createSlice({
  name: 'photos',
  initialState,
  reducers: {
    setPhotos(state, action) {
      state.photos = action.payload;
    },
    setIsAllPhotosView(state) {
      state.isAllPhotos = !state.isAllPhotos;
    },
  },
});

export const {setPhotos, setIsAllPhotosView} = photosSlice.actions;

export default photosSlice.reducer;
