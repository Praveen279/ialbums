import {createSlice} from '@reduxjs/toolkit';
import {Album} from 'app/types/album';

export type AlbumProps = {
  albums: Album[];
};

const initialState: AlbumProps = {
  albums: [],
};

const albumsSlice = createSlice({
  name: 'albums',
  initialState,
  reducers: {
    setAlbums(state, action) {
      state.albums = action.payload;
    },
    markAlbumAsDeleted(state, action) {
      const albumId: number = action.payload.id;
      const albumIndex: number = state.albums.findIndex(a => a.id === albumId);
      state.albums = [
        ...state.albums.slice(0, albumIndex),
        {...state.albums[albumIndex], isDeleted: true},
        ...state.albums.slice(albumIndex + 1),
      ];
    },
  },
});

export const {markAlbumAsDeleted, setAlbums} = albumsSlice.actions;

export default albumsSlice.reducer;
