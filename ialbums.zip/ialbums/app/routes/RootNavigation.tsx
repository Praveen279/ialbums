/**
 * This is a Navigation file which is wired already with Bottom Tab Navigation.
 * If you don't like it, feel free to replace with your own setup.
 * Uncomment commented lines from return() of RootNavigation to wire Login flow
 */
import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
// import {useSelector, useDispatch} from 'react-redux';

// Hook for theme change (Light/Dark Mode)
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import UsersWithAlbums from '../screens/UsersWithAlbums';
import {PhotoList} from '../screens/PhotoList';
import NativeCounterComponent from '../screens/NativeCounter';

// Root Navigation
const Stack = createNativeStackNavigator();

export default function RootNavigation() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown: true,
        }}>
        <Stack.Screen name="Users" component={UsersWithAlbums} />
        <Stack.Screen name="Photos" component={PhotoList} />
        <Stack.Screen
          name="Native Counter"
          component={NativeCounterComponent}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
