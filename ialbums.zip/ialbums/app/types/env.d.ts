declare module '@env' {
  export const API_URL: string;
  export const STORYBOOK_MODE: string;
}
