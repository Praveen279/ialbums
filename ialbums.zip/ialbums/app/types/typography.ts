export interface FontWeights {
  '400': string;
  '500': string;
  '700': string;
}

export interface Fonts {
  weights: FontWeights;
}

interface TypographyBase {
  fontSize: number;
  letterSpacing: number;
  lineHeight: number;
}

export interface Typography {
  caption: TypographyBase;
  small: TypographyBase;
  bodySmall: TypographyBase;
  bodyLarge: TypographyBase;
  headerSubtitle: TypographyBase;
  headerSmall: TypographyBase;
  headerLarge: TypographyBase;
}
