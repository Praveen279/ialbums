export interface Album {
  id: number;
  userId: number;
  title: string;
  isDeleted: boolean;
}
